package com.iranianprovpn.app

import android.app.Application

class Application : Application() {
    // برای Flutter جدید نیازی به کد خاصی نیست
}